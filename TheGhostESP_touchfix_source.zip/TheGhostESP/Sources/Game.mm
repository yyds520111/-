//
//  Game.mm
//  TheGhostESP
//

#import "Game.h"
#import "Names.h"
#import <Foundation/Foundation.h>
#import <string.h>

TGOffsets g_off;

static Il2CppClass *g_gmClass = NULL;
static Il2CppClass *g_neClass = NULL;
static Il2CppClass *g_necClass = NULL;
static Il2CppClass *g_transformClass = NULL;
static Il2CppClass *g_cameraClass = NULL;
static Il2CppClass *g_animatorClass = NULL;
static Il2CppClass *g_componentClass = NULL;
static Il2CppClass *g_screenClass = NULL;
static Il2CppClass *g_tmpClass = NULL;

static const MethodInfo *m_getInstance = NULL;
static const MethodInfo *m_getGFX = NULL;
static const MethodInfo *m_getPosition = NULL;
static const MethodInfo *m_getMain = NULL;
static const MethodInfo *m_worldToScreen = NULL;
static const MethodInfo *m_getBone = NULL;
static const MethodInfo *m_getTransform = NULL;
static const MethodInfo *m_screenW = NULL;
static const MethodInfo *m_screenH = NULL;
static const MethodInfo *m_getText = NULL;

static int g_bound = 0;

// 在全部程序集里找“名字对上、并且带指定字段”的类（同名类有好几个，必须挑对）
static Il2CppClass *tg_find_class_with_field(const char *name, const char *field) {
    Il2CppDomain *domain = g_il2cpp.domain_get();
    if (!domain) return NULL;
    size_t count = 0;
    const Il2CppAssembly **assemblies = g_il2cpp.domain_get_assemblies(domain, &count);
    if (!assemblies) return NULL;
    for (size_t a = 0; a < count; a++) {
        const Il2CppImage *image = g_il2cpp.assembly_get_image(assemblies[a]);
        if (!image) continue;
        size_t classCount = g_il2cpp.image_get_class_count(image);
        for (size_t i = 0; i < classCount; i++) {
            Il2CppClass *klass = g_il2cpp.image_get_class(image, i);
            if (!klass) continue;
            const char *cname = g_il2cpp.class_get_name(klass);
            if (!cname || strcmp(cname, name) != 0) continue;
            if (!il2cpp_find_field(klass, field)) continue;
            return klass;
        }
    }
    return NULL;
}

int tg_game_bind(void) {
    if (g_bound) return 1;
    if (!il2cpp_api_load()) return 0;

    g_gmClass  = il2cpp_find_class("GameManager", "GameClient");
    g_necClass = il2cpp_find_class("NetworkEntityClient", NULL);
    g_neClass  = tg_find_class_with_field("NetworkEntity", "PrefabId");
    g_transformClass = il2cpp_find_class("Transform", "UnityEngine");
    g_cameraClass    = il2cpp_find_class("Camera", "UnityEngine");
    g_animatorClass  = il2cpp_find_class("Animator", "UnityEngine");
    g_componentClass = il2cpp_find_class("Component", "UnityEngine");
    g_screenClass    = il2cpp_find_class("Screen", "UnityEngine");
    g_tmpClass       = il2cpp_find_class("TextMeshProUGUI", "TMPro");

    if (!g_gmClass || !g_necClass || !g_neClass || !g_transformClass || !g_cameraClass) {
        NSLog(@"[TheGhostESP] 绑定失败 gm=%p nec=%p ne=%p tr=%p cam=%p",
              g_gmClass, g_necClass, g_neClass, g_transformClass, g_cameraClass);
        return 0;
    }

    m_getInstance   = il2cpp_find_method(g_gmClass, "get_Instance", 0);
    m_getGFX        = il2cpp_find_method(g_neClass, "get_GFX", 0);
    m_getPosition   = il2cpp_find_method(g_transformClass, "get_position", 0);
    m_getMain       = il2cpp_find_method(g_cameraClass, "get_main", 0);
    m_worldToScreen = il2cpp_find_method(g_cameraClass, "WorldToScreenPoint", 1);
    m_getBone       = g_animatorClass ? il2cpp_find_method(g_animatorClass, "GetBoneTransform", 1) : NULL;
    m_getTransform  = g_componentClass ? il2cpp_find_method(g_componentClass, "get_transform", 0) : NULL;
    m_screenW       = g_screenClass ? il2cpp_find_method(g_screenClass, "get_width", 0) : NULL;
    m_screenH       = g_screenClass ? il2cpp_find_method(g_screenClass, "get_height", 0) : NULL;
    m_getText       = g_tmpClass ? il2cpp_find_method(g_tmpClass, "get_text", 0) : NULL;

    if (!m_getInstance || !m_getPosition || !m_getMain || !m_worldToScreen) {
        NSLog(@"[TheGhostESP] 关键方法缺失 inst=%p pos=%p main=%p w2s=%p",
              m_getInstance, m_getPosition, m_getMain, m_worldToScreen);
        return 0;
    }

    // 字段偏移：名字优先，dump 值兜底
    g_off.gm_clients             = il2cpp_field_offset(g_gmClass, "clients", 0x20);
    g_off.gm_cachedEntities      = il2cpp_field_offset(g_gmClass, "cachedEntities", 0x120);
    g_off.gm_cachedInteractables = il2cpp_field_offset(g_gmClass, "cachedInteractableEntities", 0x128);
    g_off.gm_localPlayer         = il2cpp_field_offset(g_gmClass, "_localPlayer", 0x38);

    g_off.ne_id       = il2cpp_field_offset(g_neClass, "Id", 0x20);
    g_off.ne_prefabId = il2cpp_field_offset(g_neClass, "PrefabId", 0x2C);
    g_off.ne_gfx      = il2cpp_field_offset(g_neClass, "_gfx", 0x78);

    g_off.nec_model        = il2cpp_field_offset(g_necClass, "characterModelType", 0x1A4);
    g_off.nec_animator     = il2cpp_field_offset(g_necClass, "_animator", 0x3C0);
    g_off.nec_usernameText = il2cpp_field_offset(g_necClass, "usernameText", 0x468);
    g_off.nec_enemy        = il2cpp_field_offset(g_necClass, "enemy", 0x528);
    g_off.nec_dead         = il2cpp_field_offset(g_necClass, "PlayerDead", 0x531);
    if (g_off.nec_dead == 0x531) { // 属性字段真实名是 <PlayerDead>k__BackingField
        g_off.nec_dead = il2cpp_field_offset(g_necClass, "<PlayerDead>k__BackingField", 0x531);
    }

    g_bound = 1;
    NSLog(@"[TheGhostESP] 绑定成功 clients=0x%X entities=0x%X gfx=0x%X animator=0x%X enemy=0x%X",
          g_off.gm_clients, g_off.gm_cachedEntities, g_off.ne_gfx, g_off.nec_animator, g_off.nec_enemy);
    return 1;
}

bool tg_game_bound(void) { return g_bound != 0; }

void *tg_gm_instance(void) {
    if (!m_getInstance) return NULL;
    static void *fn = NULL;
    if (!fn) fn = il2cpp_method_ptr(m_getInstance);
    if (!fn) return NULL;
    return ((void *(*)(const MethodInfo *))fn)(m_getInstance);
}

void *tg_camera_main(void) {
    if (!m_getMain) return NULL;
    static void *fn = NULL;
    if (!fn) fn = il2cpp_method_ptr(m_getMain);
    if (!fn) return NULL;
    return ((void *(*)(const MethodInfo *))fn)(m_getMain);
}

bool tg_world_to_screen(void *camera, Vec3 world, Vec3 *outScreen) {
    if (!camera || !m_worldToScreen || !outScreen) return false;
    static void *fn = NULL;
    if (!fn) fn = il2cpp_method_ptr(m_worldToScreen);
    if (!fn) return false;
    Vec3 r = ((Vec3(*)(void *, Vec3, const MethodInfo *))fn)(camera, world, m_worldToScreen);
    *outScreen = r;
    return r.z > 0.01f;
}

void tg_unity_screen_size(float *w, float *h) {
    float sw = 0.f, sh = 0.f;
    if (m_screenW) {
        static void *fnW = NULL;
        if (!fnW) fnW = il2cpp_method_ptr(m_screenW);
        if (fnW) sw = (float)((int32_t(*)(const MethodInfo *))fnW)(m_screenW);
    }
    if (m_screenH) {
        static void *fnH = NULL;
        if (!fnH) fnH = il2cpp_method_ptr(m_screenH);
        if (fnH) sh = (float)((int32_t(*)(const MethodInfo *))fnH)(m_screenH);
    }
    if (sw <= 1.f) sw = 1920.f;
    if (sh <= 1.f) sh = 1080.f;
    if (w) *w = sw;
    if (h) *h = sh;
}

bool tg_transform_position(void *transform, Vec3 *out) {
    if (!transform || !m_getPosition || !out) return false;
    static void *fn = NULL;
    if (!fn) fn = il2cpp_method_ptr(m_getPosition);
    if (!fn) return false;
    *out = ((Vec3(*)(void *, const MethodInfo *))fn)(transform, m_getPosition);
    return true;
}

void *tg_entity_gfx(void *entity) {
    if (!entity) return NULL;
    void *gfx = tg_read_ptr(entity, g_off.ne_gfx);
    if (gfx) {
        const char *cn = tg_object_class_name(gfx);
        if (!cn || strcmp(cn, "Transform") == 0) return gfx;
    }
    if (m_getGFX) {
        static void *fn = NULL;
        if (!fn) fn = il2cpp_method_ptr(m_getGFX);
        if (fn) return ((void *(*)(void *, const MethodInfo *))fn)(entity, m_getGFX);
    }
    return tg_entity_transform(entity);
}

void *tg_entity_transform(void *entity) {
    if (!entity || !m_getTransform) return NULL;
    static void *fn = NULL;
    if (!fn) fn = il2cpp_method_ptr(m_getTransform);
    if (!fn) return NULL;
    return ((void *(*)(void *, const MethodInfo *))fn)(entity, m_getTransform);
}

void *tg_local_player(void) {
    void *gm = tg_gm_instance();
    if (!gm) return NULL;
    return tg_read_ptr(gm, g_off.gm_localPlayer);
}

bool tg_local_player_position(Vec3 *out) {
    void *lp = tg_local_player();
    if (lp) {
        void *t = tg_entity_gfx(lp);
        if (tg_transform_position(t, out)) return true;
    }
    void *cam = tg_camera_main();
    if (cam) {
        void *t = tg_entity_transform(cam);
        if (tg_transform_position(t, out)) return true;
    }
    return false;
}

void *tg_bone(void *animator, int humanBoneId) {
    if (!animator || !m_getBone) return NULL;
    const char *cn = tg_object_class_name(animator);
    if (cn && strcmp(cn, "Animator") != 0) return NULL;
    static void *fn = NULL;
    if (!fn) fn = il2cpp_method_ptr(m_getBone);
    if (!fn) return NULL;
    return ((void *(*)(void *, int32_t, const MethodInfo *))fn)(animator, humanBoneId, m_getBone);
}

NSString *tg_username(void *client) {
    if (!client || !m_getText) return nil;
    void *tmp = tg_read_ptr(client, g_off.nec_usernameText);
    if (!tmp) return nil;
    const char *cn = tg_object_class_name(tmp);
    if (cn && !strstr(cn, "TextMeshPro")) return nil;
    static void *fn = NULL;
    if (!fn) fn = il2cpp_method_ptr(m_getText);
    if (!fn) return nil;
    void *str = ((void *(*)(void *, const MethodInfo *))fn)(tmp, m_getText);
    NSString *s = tg_nsstring(str);
    if (!s) return nil;
    s = [s stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    return s.length ? s : nil;
}

bool tg_client_valid(void *client) {
    if (!client) return false;
    int model = tg_read_i32(client, g_off.nec_model);
    if (model < 0 || model > 64) return false;
    return true;
}
