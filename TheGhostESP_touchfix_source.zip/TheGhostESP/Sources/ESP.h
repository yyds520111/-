//
//  ESP.h
//  TheGhostESP
//

#ifndef ESP_H
#define ESP_H

#import <CoreGraphics/CoreGraphics.h>
#import <stdbool.h>

#define TG_MAX_GHOSTS 32
#define TG_MAX_ITEMS  64
#define TG_BONE_COUNT 19
#define TG_SKEL_SEGS  18

// 屏幕坐标全部用归一化值（0~1，左上角原点），绘制时再乘视图尺寸
typedef struct {
    CGPoint head;
    CGPoint feet;
    bool hasHead;
    bool hasFeet;
    bool hasBox;
    float distance;
    char  name[96];
    char  sub[32];
    bool  ghost;
    CGPoint bones[TG_BONE_COUNT];   // Hips..RightHand，下标即 HumanBodyBones 0~18
    bool  boneValid[TG_BONE_COUNT];

    // 已经算好的骨骼线段（两点一组），绘制时直接连线，不用再查骨骼表
    CGPoint skel[TG_SKEL_SEGS * 2];
    int skelCount;
} TGEntityDraw;

typedef struct {
    TGEntityDraw ghosts[TG_MAX_GHOSTS];
    int ghostCount;
    TGEntityDraw items[TG_MAX_ITEMS];
    int itemCount;
    bool ready;
} TGFrame;

typedef struct {
    bool ghostOn;
    bool ghostBox;
    bool ghostSkel;
    bool ghostName;
    bool ghostDist;
    bool ghostRay;
    bool onlyEnemy;
    bool itemOn;
    bool itemName;
    bool itemCount;
    bool itemDist;
    float maxDist;
} TGSettings;

extern TGSettings g_set;

void tg_settings_load(void);
void tg_settings_save(void);

void tg_esp_start(void);
void tg_esp_stop(void);

/// 主线程取一帧快照
void tg_esp_copy_frame(TGFrame *out);

#endif /* ESP_H */
