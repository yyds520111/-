//
//  IL2CPP.mm
//  TheGhostESP
//

#import "IL2CPP.h"
#import <Foundation/Foundation.h>
#import <dlfcn.h>
#import <string.h>

IL2CPPApi g_il2cpp;
int        g_il2cppReady = 0;

static NSMutableDictionary<NSString *, id> *g_classCache = nil;

// ---------------------------------------------------------------------------
// 符号解析：Unity 的 UnityFramework 已经把 il2cpp_* 导出在本进程里，
// 直接 dlsym(RTLD_DEFAULT) 即可；个别渠道包会去掉前缀，做一次兼容。
// ---------------------------------------------------------------------------
static void *tg_sym(const char *primary, const char *fallback) {
    void *p = dlsym(RTLD_DEFAULT, primary);
    if (p) return p;
    if (fallback) {
        p = dlsym(RTLD_DEFAULT, fallback);
        if (p) return p;
    }
    // 有些包把 UnityFramework 作为独立 framework 加载
    static void *handle = NULL;
    if (!handle) handle = dlopen(NULL, RTLD_LAZY);
    if (handle) {
        p = dlsym(handle, primary);
        if (!p && fallback) p = dlsym(handle, fallback);
    }
    return p;
}

#define TG_ASSIGN(field, sym) \
    do { g_il2cpp.field = (__typeof__(g_il2cpp.field))(sym); } while (0)

#define TG_LOAD(field, name)                                        \
    do {                                                            \
        TG_ASSIGN(field, tg_sym("il2cpp_" name, name));              \
        if (!g_il2cpp.field) {                                      \
            NSLog(@"[TheGhostESP] 缺少符号: %s", name);              \
            missing++;                                              \
        }                                                           \
    } while (0)

#define TG_LOAD_OPT(field, name)                                    \
    do { TG_ASSIGN(field, tg_sym("il2cpp_" name, name)); } while (0)

int il2cpp_api_load(void) {
    if (g_il2cppReady) return 1;
    int missing = 0;

    TG_LOAD(domain_get, "domain_get");
    TG_LOAD(domain_get_assemblies, "domain_get_assemblies");
    TG_LOAD(assembly_get_image, "assembly_get_image");
    TG_LOAD(image_get_name, "image_get_name");
    TG_LOAD(image_get_class_count, "image_get_class_count");
    TG_LOAD(image_get_class, "image_get_class");
    TG_LOAD(class_get_name, "class_get_name");
    TG_LOAD(class_get_namespace, "class_get_namespace");
    TG_LOAD(class_get_parent, "class_get_parent");
    TG_LOAD(class_from_name, "class_from_name");
    TG_LOAD(class_get_field_from_name, "class_get_field_from_name");
    TG_LOAD(field_get_offset, "field_get_offset");
    TG_LOAD(class_get_method_from_name, "class_get_method_from_name");
    TG_LOAD(runtime_invoke, "runtime_invoke");
    TG_LOAD(object_unbox, "object_unbox");
    TG_LOAD_OPT(object_get_class, "object_get_class");
    TG_LOAD(thread_attach, "thread_attach");
    TG_LOAD_OPT(method_get_pointer, "method_get_pointer");

    if (missing > 0) {
        g_il2cppReady = 0;
        return 0;
    }
    g_il2cppReady = 1;
    if (!g_classCache) g_classCache = [NSMutableDictionary new];
    return 1;
}

// ---------------------------------------------------------------------------
// 类查找
// ---------------------------------------------------------------------------
Il2CppClass *il2cpp_find_class(const char *name, const char *ns) {
    if (!g_il2cppReady || !name) return NULL;

    NSString *key = [NSString stringWithFormat:@"%s::%s", ns ? ns : "*", name];
    id cached = g_classCache[key];
    if (cached) return (Il2CppClass *)[cached pointerValue];

    Il2CppDomain *domain = g_il2cpp.domain_get();
    if (!domain) return NULL;

    size_t count = 0;
    const Il2CppAssembly **assemblies = g_il2cpp.domain_get_assemblies(domain, &count);
    if (!assemblies) return NULL;

    Il2CppClass *found = NULL;
    for (size_t a = 0; a < count && !found; a++) {
        const Il2CppImage *image = g_il2cpp.assembly_get_image(assemblies[a]);
        if (!image) continue;
        size_t classCount = g_il2cpp.image_get_class_count(image);
        for (size_t i = 0; i < classCount; i++) {
            Il2CppClass *klass = g_il2cpp.image_get_class(image, i);
            if (!klass) continue;
            const char *cname = g_il2cpp.class_get_name(klass);
            if (!cname || strcmp(cname, name) != 0) continue;
            if (ns) {
                const char *cns = g_il2cpp.class_get_namespace(klass);
                if (!cns || strcmp(cns, ns) != 0) continue;
            }
            found = klass;
            break;
        }
    }

    if (found) g_classCache[key] = [NSValue valueWithPointer:found];
    return found;
}

FieldInfo *il2cpp_find_field(Il2CppClass *klass, const char *name) {
    if (!klass || !name) return NULL;
    for (Il2CppClass *k = klass; k != NULL; k = g_il2cpp.class_get_parent(k)) {
        FieldInfo *f = g_il2cpp.class_get_field_from_name(k, name);
        if (f) return f;
    }
    return NULL;
}

int il2cpp_field_offset(Il2CppClass *klass, const char *name, int fallback) {
    FieldInfo *f = il2cpp_find_field(klass, name);
    if (!f) return fallback;
    int32_t off = g_il2cpp.field_get_offset(f);
    return off > 0 ? off : fallback;
}

const MethodInfo *il2cpp_find_method(Il2CppClass *klass, const char *name, int argsCount) {
    if (!klass || !name) return NULL;
    for (Il2CppClass *k = klass; k != NULL; k = g_il2cpp.class_get_parent(k)) {
        const MethodInfo *m = g_il2cpp.class_get_method_from_name(k, name, argsCount);
        if (m) return m;
    }
    return NULL;
}

void *il2cpp_method_ptr(const MethodInfo *method) {
    if (!method) return NULL;
    if (g_il2cpp.method_get_pointer) {
        void *p = g_il2cpp.method_get_pointer(method);
        if (p) return p;
    }
    // MethodInfo 的第一个成员就是 methodPointer
    void *p = *(void **)method;
    return p;
}

const char *tg_object_class_name(void *obj) {
    if (!obj || !g_il2cpp.object_get_class) return NULL;
    Il2CppClass *klass = g_il2cpp.object_get_class((Il2CppObject *)obj);
    if (!klass) return NULL;
    return g_il2cpp.class_get_name(klass);
}

// ---------------------------------------------------------------------------
// 字符串
// ---------------------------------------------------------------------------
bool tg_looks_like_string(void *ptr) {
    if (!ptr) return false;
    int32_t len = tg_string_length(ptr);
    return len >= 0 && len <= 512;
}

NSString *tg_nsstring(void *il2cppString) {
    if (!il2cppString) return nil;
    int32_t len = tg_string_length(il2cppString);
    if (len <= 0 || len > 512) return nil;
    const uint16_t *chars = tg_string_chars(il2cppString);
    if (!chars) return nil;
    NSString *s = [NSString stringWithCharacters:chars length:(NSUInteger)len];
    if (!s) return nil;
    // 去掉富文本残留
    if ([s containsString:@"<"]) {
        s = [s stringByReplacingOccurrencesOfString:@"<color=#00000000>" withString:@""];
    }
    return s;
}
