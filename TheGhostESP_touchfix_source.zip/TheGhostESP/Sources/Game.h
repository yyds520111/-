//
//  Game.h
//  TheGhostESP
//
//  游戏对象绑定层：类 / 字段 / 方法全部在运行时按名字解析。
//

#ifndef GAME_H
#define GAME_H

#import "IL2CPP.h"

// 字段偏移：运行时优先按名字解析，解析不到才用 dump 里的值兜底
typedef struct {
    // GameClient.GameManager
    int gm_clients;              // 0x20  NetworkEntityClient[]
    int gm_cachedEntities;       // 0x120 NetworkEntity[]
    int gm_cachedInteractables;  // 0x128 NetworkEntityInteractable[]
    int gm_localPlayer;          // 0x38  NetworkEntityLocalPlayer

    // NetworkEntity
    int ne_id;                   // 0x20  Int16
    int ne_prefabId;             // 0x2C  UInt16
    int ne_gfx;                  // 0x78  Transform

    // NetworkEntityClient
    int nec_model;               // 0x1A4 Model
    int nec_animator;            // 0x3C0 Animator
    int nec_usernameText;        // 0x468 TextMeshProUGUI
    int nec_enemy;               // 0x528 Boolean
    int nec_dead;                // 0x531 Boolean
} TGOffsets;

extern TGOffsets g_off;

/// 绑定游戏类/方法，成功返回 1（失败会返回 0，可反复重试）
int  tg_game_bind(void);
bool tg_game_bound(void);

void *tg_gm_instance(void);
void *tg_camera_main(void);

/// 世界坐标 -> Unity 屏幕像素坐标（左下角原点）
bool tg_world_to_screen(void *camera, Vec3 world, Vec3 *outScreen);

/// 屏幕像素尺寸（Unity Screen.width / height）
void tg_unity_screen_size(float *w, float *h);

/// 组件/实体位置
bool tg_transform_position(void *transform, Vec3 *out);
void *tg_entity_gfx(void *entity);
void *tg_entity_transform(void *entity);   // 兜底：走 Component.transform
void *tg_local_player(void);
bool tg_local_player_position(Vec3 *out);

/// 骨骼
void *tg_bone(void *animator, int humanBoneId);

/// 头顶用户名（TextMeshProUGUI），拿不到返回 nil
NSString *tg_username(void *client);

/// 对象是否像“活着的 NetworkEntityClient”
bool tg_client_valid(void *client);

#endif /* GAME_H */
