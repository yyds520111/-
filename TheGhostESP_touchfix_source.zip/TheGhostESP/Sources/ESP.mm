//
//  ESP.mm
//  TheGhostESP
//
//  扫描 + 投影。全部跑在独立线程，主线程只负责画。
//

#import "ESP.h"
#import "Game.h"
#import "Names.h"
#import <Foundation/Foundation.h>
#import <pthread.h>
#import <math.h>
#import <string.h>
#import <stdio.h>

TGSettings g_set;

static TGFrame g_frame;
static pthread_mutex_t g_frameLock = PTHREAD_MUTEX_INITIALIZER;

static dispatch_queue_t g_queue = NULL;
static dispatch_source_t g_timer = NULL;
static bool g_running = false;

// 骨骼连线（下标对应 HumanBodyBones 0~18）
static const int kBonePairs[][2] = {
    {10, 9},   // 头 - 颈
    {9, 8},    // 颈 - 胸
    {8, 7},    // 胸 - 脊椎
    {7, 0},    // 脊椎 - 胯
    {0, 1}, {1, 3}, {3, 5},     // 左腿
    {0, 2}, {2, 4}, {4, 6},     // 右腿
    {9, 11}, {11, 13}, {13, 15}, {15, 17},   // 左臂
    {9, 12}, {12, 14}, {14, 16}, {16, 18},   // 右臂
};

// ---------------------------------------------------------------------------
// 设置持久化
// ---------------------------------------------------------------------------
static NSUserDefaults *tg_defaults(void) { return [NSUserDefaults standardUserDefaults]; }

void tg_settings_load(void) {
    NSUserDefaults *d = tg_defaults();
    g_set.ghostOn   = [d objectForKey:@"ghostOn"]   ? [d boolForKey:@"ghostOn"]   : true;
    g_set.ghostBox  = [d objectForKey:@"ghostBox"]  ? [d boolForKey:@"ghostBox"]  : true;
    g_set.ghostSkel = [d objectForKey:@"ghostSkel"] ? [d boolForKey:@"ghostSkel"] : true;
    g_set.ghostName = [d objectForKey:@"ghostName"] ? [d boolForKey:@"ghostName"] : true;
    g_set.ghostDist = [d objectForKey:@"ghostDist"] ? [d boolForKey:@"ghostDist"] : true;
    g_set.ghostRay  = [d objectForKey:@"ghostRay"]  ? [d boolForKey:@"ghostRay"]  : false;
    g_set.onlyEnemy = [d objectForKey:@"onlyEnemy"] ? [d boolForKey:@"onlyEnemy"] : true;
    g_set.itemOn    = [d objectForKey:@"itemOn"]    ? [d boolForKey:@"itemOn"]    : true;
    g_set.itemName  = [d objectForKey:@"itemName"]  ? [d boolForKey:@"itemName"]  : true;
    g_set.itemCount = [d objectForKey:@"itemCount"] ? [d boolForKey:@"itemCount"] : true;
    g_set.itemDist  = [d objectForKey:@"itemDist"]  ? [d boolForKey:@"itemDist"]  : true;
    float md = [d objectForKey:@"maxDist"] ? [d floatForKey:@"maxDist"] : 150.f;
    g_set.maxDist = (md > 1.f) ? md : 150.f;
}

void tg_settings_save(void) {
    NSUserDefaults *d = tg_defaults();
    [d setBool:g_set.ghostOn   forKey:@"ghostOn"];
    [d setBool:g_set.ghostBox  forKey:@"ghostBox"];
    [d setBool:g_set.ghostSkel forKey:@"ghostSkel"];
    [d setBool:g_set.ghostName forKey:@"ghostName"];
    [d setBool:g_set.ghostDist forKey:@"ghostDist"];
    [d setBool:g_set.ghostRay  forKey:@"ghostRay"];
    [d setBool:g_set.onlyEnemy forKey:@"onlyEnemy"];
    [d setBool:g_set.itemOn    forKey:@"itemOn"];
    [d setBool:g_set.itemName  forKey:@"itemName"];
    [d setBool:g_set.itemCount forKey:@"itemCount"];
    [d setBool:g_set.itemDist  forKey:@"itemDist"];
    [d setFloat:g_set.maxDist  forKey:@"maxDist"];
    [d synchronize];
}

// ---------------------------------------------------------------------------
// 投影
// ---------------------------------------------------------------------------
static bool tg_project(void *cam, Vec3 world, float sw, float sh, CGPoint *out) {
    Vec3 s;
    if (!tg_world_to_screen(cam, world, &s)) return false;
    if (s.x < -sw || s.x > sw * 2.f) return false;
    if (s.y < -sh || s.y > sh * 2.f) return false;
    out->x = s.x / sw;
    out->y = 1.f - s.y / sh;
    return true;
}

static float tg_dist(Vec3 a, Vec3 b) {
    float dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
    return sqrtf(dx * dx + dy * dy + dz * dz);
}

static void tg_set_text(char *dst, size_t cap, NSString *s) {
    if (!dst || cap == 0) return;
    dst[0] = '\0';
    if (!s) return;
    const char *utf8 = s.UTF8String;
    if (!utf8) return;
    strncpy(dst, utf8, cap - 1);
    dst[cap - 1] = '\0';
}

// ---------------------------------------------------------------------------
// 扫描
// ---------------------------------------------------------------------------
typedef struct { uint16_t prefab; int count; } TGItemTally;

static void tg_scan(TGFrame *f) {
    memset(f, 0, sizeof(*f));

    if (!tg_game_bound() && !tg_game_bind()) return;

    void *gm = tg_gm_instance();
    if (!gm) return;
    void *cam = tg_camera_main();
    if (!cam) return;

    float sw = 1920.f, sh = 1080.f;
    tg_unity_screen_size(&sw, &sh);

    Vec3 local = {0, 0, 0};
    bool haveLocal = tg_local_player_position(&local);
    void *localPlayer = tg_local_player();

    // ---------------- 鬼（敌方玩家 / 怪物） ----------------
    if (g_set.ghostOn) {
        void *clients = tg_read_ptr(gm, g_off.gm_clients);
        size_t count = tg_array_len(clients);
        for (size_t i = 0; i < count && f->ghostCount < TG_MAX_GHOSTS; i++) {
            void *client = tg_array_at(clients, i);
            if (!client || client == localPlayer) continue;
            if (!tg_client_valid(client)) continue;

            bool enemy = tg_read_u8(client, g_off.nec_enemy);
            if (g_set.onlyEnemy && !enemy) continue;
            if (tg_read_u8(client, g_off.nec_dead)) continue;

            void *gfx = tg_entity_gfx(client);
            Vec3 pos;
            if (!tg_transform_position(gfx, &pos)) continue;

            float d = haveLocal ? tg_dist(pos, local) : 0.f;
            if (g_set.maxDist > 1.f && d > g_set.maxDist) continue;

            TGEntityDraw e;
            memset(&e, 0, sizeof(e));
            e.ghost = true;
            e.distance = d;

            // 骨骼
            void *animator = tg_read_ptr(client, g_off.nec_animator);
            if (animator) {
                for (int b = 0; b < TG_BONE_COUNT; b++) {
                    void *bone = tg_bone(animator, b);
                    if (!bone) continue;
                    Vec3 bp;
                    if (!tg_transform_position(bone, &bp)) continue;
                    CGPoint p;
                    if (!tg_project(cam, bp, sw, sh, &p)) continue;
                    e.bones[b] = p;
                    e.boneValid[b] = true;
                }
            }

            // 头 / 脚
            if (e.boneValid[10]) {
                e.head = e.bones[10];
                e.hasHead = true;
            } else {
                Vec3 top = pos;
                top.y += 1.75f;
                if (tg_project(cam, top, sw, sh, &e.head)) e.hasHead = true;
            }
            if (e.boneValid[5] || e.boneValid[6]) {
                CGPoint best = e.boneValid[5] ? e.bones[5] : e.bones[6];
                if (e.boneValid[5] && e.boneValid[6] && e.bones[6].y > best.y) best = e.bones[6];
                e.feet = best;
                e.hasFeet = true;
            } else if (tg_project(cam, pos, sw, sh, &e.feet)) {
                e.hasFeet = true;
            }
            e.hasBox = e.hasHead && e.hasFeet && (e.feet.y - e.head.y) > 0.01f;

            // 骨骼连线（画的时候直接连，省得再查表）
            if (g_set.ghostSkel) {
                for (size_t s = 0; s < sizeof(kBonePairs) / sizeof(kBonePairs[0]); s++) {
                    int a = kBonePairs[s][0];
                    int b = kBonePairs[s][1];
                    if (!e.boneValid[a] || !e.boneValid[b]) continue;
                    if (e.skelCount >= TG_SKEL_SEGS) break;
                    e.skel[e.skelCount * 2]     = e.bones[a];
                    e.skel[e.skelCount * 2 + 1] = e.bones[b];
                    e.skelCount++;
                }
            }

            // 名字：模型中文名 + 玩家名
            int model = tg_read_i32(client, g_off.nec_model);
            NSString *uname = tg_username(client);
            NSString *title = uname.length
                ? [NSString stringWithFormat:@"%s · %@", tg_model_name(model), uname]
                : [NSString stringWithFormat:@"%s", tg_model_name(model)];
            tg_set_text(e.name, sizeof(e.name), title);

            if (g_set.ghostDist) {
                snprintf(e.sub, sizeof(e.sub), "%dm", (int)roundf(d));
            }

            f->ghosts[f->ghostCount++] = e;
        }
    }

    // ---------------- 物品（拾取物 + 任务物品） ----------------
    if (g_set.itemOn) {
        void *arr = tg_read_ptr(gm, g_off.gm_cachedEntities);
        if (tg_array_len(arr) == 0) arr = tg_read_ptr(gm, g_off.gm_cachedInteractables);

        size_t count = tg_array_len(arr);
        if (count > 512) count = 512;

        // 第一遍：把范围内的物品全部收下来
        int n = 0;
        for (size_t i = 0; i < count && n < TG_MAX_ITEMS; i++) {
            void *ent = tg_array_at(arr, i);
            if (!ent) continue;

            uint16_t prefab = tg_read_u16(ent, g_off.ne_prefabId);
            if (!tg_is_item_prefab(prefab)) continue;

            void *gfx = tg_entity_gfx(ent);
            Vec3 pos;
            if (!tg_transform_position(gfx, &pos)) continue;

            float d = haveLocal ? tg_dist(pos, local) : 0.f;
            if (g_set.maxDist > 1.f && d > g_set.maxDist) continue;

            CGPoint p;
            if (!tg_project(cam, pos, sw, sh, &p)) continue;

            TGEntityDraw e;
            memset(&e, 0, sizeof(e));
            e.ghost = false;
            e.distance = d;
            e.head = p;
            e.feet = p;
            e.hasHead = true;
            e.hasFeet = true;
            // 先存 prefab，第二遍再填名字
            memcpy(e.name, &prefab, sizeof(prefab));

            f->items[n++] = e;
        }

        // 第二遍：按同类物品统计数量并生成中文名
        for (int i = 0; i < n; i++) {
            uint16_t prefab = 0;
            memcpy(&prefab, f->items[i].name, sizeof(prefab));

            int same = 0;
            for (int j = 0; j < n; j++) {
                uint16_t other = 0;
                memcpy(&other, f->items[j].name, sizeof(other));
                if (other == prefab) same++;
            }

            const char *cn = tg_prefab_name(prefab);
            NSString *title;
            if (g_set.itemCount && same > 1) {
                title = [NSString stringWithFormat:@"%s x%d", cn ? cn : "物品", same];
            } else {
                title = [NSString stringWithFormat:@"%s", cn ? cn : "物品"];
            }
            tg_set_text(f->items[i].name, sizeof(f->items[i].name), title);

            if (g_set.itemDist) {
                snprintf(f->items[i].sub, sizeof(f->items[i].sub), "%dm", (int)roundf(f->items[i].distance));
            }
        }
        f->itemCount = n;
    }

    f->ready = true;
}

// ---------------------------------------------------------------------------
// 循环
// ---------------------------------------------------------------------------
static void tg_loop_tick(void) {
    if (!g_set.ghostOn && !g_set.itemOn) {
        pthread_mutex_lock(&g_frameLock);
        memset(&g_frame, 0, sizeof(g_frame));
        pthread_mutex_unlock(&g_frameLock);
        return;
    }

    static TGFrame local;
    tg_scan(&local);

    pthread_mutex_lock(&g_frameLock);
    g_frame = local;
    pthread_mutex_unlock(&g_frameLock);
}

void tg_esp_start(void) {
    if (g_running) return;
    g_running = true;

    if (!g_queue) {
        g_queue = dispatch_queue_create("com.zaka.theghost.esp", DISPATCH_QUEUE_SERIAL);
    }

    g_timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, g_queue);
    dispatch_source_set_timer(g_timer,
                              dispatch_time(DISPATCH_TIME_NOW, 0),
                              (uint64_t)(NSEC_PER_SEC / 30),
                              (uint64_t)(NSEC_PER_SEC / 300));
    dispatch_source_set_event_handler(g_timer, ^{
        // 每条线程必须挂到 IL2CPP 的 GC 上
        static bool attached = false;
        if (!attached) {
            Il2CppDomain *domain = g_il2cpp.domain_get();
            if (domain && g_il2cpp.thread_attach) g_il2cpp.thread_attach(domain);
            attached = true;
        }
        tg_loop_tick();
    });
    dispatch_resume(g_timer);
}

void tg_esp_stop(void) {
    if (g_timer) {
        dispatch_source_cancel(g_timer);
        g_timer = NULL;
    }
    g_running = false;
}

void tg_esp_copy_frame(TGFrame *out) {
    if (!out) return;
    pthread_mutex_lock(&g_frameLock);
    *out = g_frame;
    pthread_mutex_unlock(&g_frameLock);
}
