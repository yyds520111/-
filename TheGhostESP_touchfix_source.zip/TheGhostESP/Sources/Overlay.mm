//
//  Overlay.mm
//  TheGhostESP
//
//  悬浮层：一块透明画布 + 一个白色简洁菜单。
//  画布不接管触摸（游戏操作不受影响），只有按钮和菜单能点。
//

#import "Overlay.h"
#import "ESP.h"
#import "Game.h"
#import <QuartzCore/QuartzCore.h>

static UIColor *TGColorGhost(void) { return [UIColor colorWithRed:1.0 green:0.21 blue:0.27 alpha:1.0]; }
static UIColor *TGColorItem(void)  { return [UIColor colorWithRed:0.36 green:0.92 blue:1.0 alpha:1.0]; }

// ---------------------------------------------------------------------------
// 只让子视图接触摸，空白处直接把事件放回游戏
// ---------------------------------------------------------------------------
@interface TGPassthroughView : UIView
@end

@implementation TGPassthroughView
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    if (self.hidden || !self.userInteractionEnabled || self.alpha < 0.01f) return nil;
    for (UIView *v in [self.subviews reverseObjectEnumerator]) {
        if (v.hidden || !v.userInteractionEnabled || v.alpha < 0.01f) continue;
        CGPoint p = [v convertPoint:point fromView:self];
        UIView *hit = [v hitTest:p withEvent:event];
        if (hit) return hit;
    }
    return nil;
}
@end

// UIWindow 默认可能把“没有命中子控件”的空白触摸落到窗口自身。
// 独立悬浮 UIWindow 必须在这种情况下返回 nil，系统才有机会把触摸交给下层游戏窗口。
@interface TGPassthroughWindow : UIWindow
@end

@implementation TGPassthroughWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *hit = [super hitTest:point withEvent:event];
    UIView *root = self.rootViewController.view;
    if (hit == self || hit == root) return nil;
    return hit;
}
@end

// ---------------------------------------------------------------------------
// 文字
// ---------------------------------------------------------------------------
static void TGText(NSString *text, CGPoint center, CGFloat size, UIColor *color) {
    if (text.length == 0) return;
    NSDictionary *attrs = @{
        NSFontAttributeName: [UIFont boldSystemFontOfSize:size],
        NSForegroundColorAttributeName: color,
        NSStrokeColorAttributeName: [UIColor colorWithWhite:0.f alpha:0.85f],
        NSStrokeWidthAttributeName: @(-2.5),
    };
    CGSize sz = [text sizeWithAttributes:attrs];
    [text drawAtPoint:CGPointMake(center.x - sz.width / 2.f, center.y - sz.height / 2.f)
       withAttributes:attrs];
}

// ---------------------------------------------------------------------------
// 透视画布
// ---------------------------------------------------------------------------
@interface TGESPView : UIView
@property (nonatomic, strong) CADisplayLink *link;
@end

@implementation TGESPView

- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        self.backgroundColor = [UIColor clearColor];
        self.opaque = NO;
        self.userInteractionEnabled = NO;
        self.clearsContextBeforeDrawing = NO;
    }
    return self;
}

- (void)didMoveToWindow {
    [super didMoveToWindow];
    [self.link invalidate];
    self.link = nil;
    if (self.window) {
        self.link = [CADisplayLink displayLinkWithTarget:self selector:@selector(tick)];
        if ([self.link respondsToSelector:@selector(setPreferredFramesPerSecond:)]) {
            self.link.preferredFramesPerSecond = 30;
        } else {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
            self.link.frameInterval = 2;
#pragma clang diagnostic pop
        }
        [self.link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
    }
}

- (void)tick { [self setNeedsDisplay]; }

- (void)dealloc { [self.link invalidate]; }

- (void)drawRect:(CGRect)rect {
    TGFrame f;
    tg_esp_copy_frame(&f);
    if (!f.ready) return;

    const CGFloat W = CGRectGetWidth(self.bounds);
    const CGFloat H = CGRectGetHeight(self.bounds);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    if (!ctx) return;

    // -------- 鬼 --------
    for (int i = 0; i < f.ghostCount; i++) {
        const TGEntityDraw *e = &f.ghosts[i];
        if (!e->hasHead) continue;

        CGPoint head = CGPointMake(e->head.x * W, e->head.y * H);
        CGPoint feet = CGPointMake(e->feet.x * W, e->feet.y * H);
        CGFloat boxH = feet.y - head.y;
        CGFloat boxW = MAX(boxH * 0.52f, 10.f);
        CGRect box = CGRectMake(head.x - boxW / 2.f, head.y, boxW, boxH);

        UIColor *color = TGColorGhost();

        // 骨骼
        if (g_set.ghostSkel && e->skelCount > 0) {
            CGContextSetStrokeColorWithColor(ctx, color.CGColor);
            CGContextSetLineWidth(ctx, 1.0f);
            for (int s = 0; s < e->skelCount; s++) {
                CGPoint a = CGPointMake(e->skel[s * 2].x * W, e->skel[s * 2].y * H);
                CGPoint b = CGPointMake(e->skel[s * 2 + 1].x * W, e->skel[s * 2 + 1].y * H);
                CGContextMoveToPoint(ctx, a.x, a.y);
                CGContextAddLineToPoint(ctx, b.x, b.y);
            }
            CGContextStrokePath(ctx);
        }

        // 方框
        if (g_set.ghostBox && e->hasBox) {
            CGContextSetStrokeColorWithColor(ctx, color.CGColor);
            CGContextSetLineWidth(ctx, 1.4f);
            CGContextStrokeRect(ctx, box);
        }

        // 射线（屏幕底部中点 -> 目标）
        if (g_set.ghostRay) {
            CGContextSetStrokeColorWithColor(ctx, color.CGColor);
            CGContextSetLineWidth(ctx, 0.9f);
            CGContextMoveToPoint(ctx, W / 2.f, H);
            CGContextAddLineToPoint(ctx, CGRectGetMidX(box), CGRectGetMaxY(box));
            CGContextStrokePath(ctx);
        }

        // 名字 + 距离
        NSString *name = [NSString stringWithUTF8String:e->name];
        if (name.length == 0) name = @"鬼";
        if (g_set.ghostName) {
            NSString *line = e->sub[0] ? [NSString stringWithFormat:@"%@  %s", name, e->sub] : name;
            TGText(line, CGPointMake(CGRectGetMidX(box), CGRectGetMinY(box) - 10.f), 11.f, color);
        } else if (e->sub[0]) {
            TGText([NSString stringWithUTF8String:e->sub],
                   CGPointMake(CGRectGetMidX(box), CGRectGetMinY(box) - 10.f), 10.f, color);
        }
    }

    // -------- 物品 --------
    for (int i = 0; i < f.itemCount; i++) {
        const TGEntityDraw *e = &f.items[i];
        if (!e->hasHead) continue;
        CGPoint p = CGPointMake(e->head.x * W, e->head.y * H);
        if (p.x < -40.f || p.x > W + 40.f || p.y < -40.f || p.y > H + 40.f) continue;

        UIColor *color = TGColorItem();
        CGContextSetFillColorWithColor(ctx, color.CGColor);
        CGContextFillEllipseInRect(ctx, CGRectMake(p.x - 2.f, p.y - 2.f, 4.f, 4.f));

        NSString *name = [NSString stringWithUTF8String:e->name];
        if (name.length == 0) name = @"物品";
        if (g_set.itemName) {
            NSString *line = e->sub[0] ? [NSString stringWithFormat:@"%@  %s", name, e->sub] : name;
            TGText(line, CGPointMake(p.x, p.y - 12.f), 10.f, color);
        } else if (e->sub[0]) {
            TGText([NSString stringWithUTF8String:e->sub], CGPointMake(p.x, p.y - 12.f), 10.f, color);
        }
    }
}

@end

// ---------------------------------------------------------------------------
// 白色菜单
// ---------------------------------------------------------------------------
static const CGFloat kPanelWidth = 254.f;
static const CGFloat kRowHeight = 34.f;

@interface TGMenuPanel : UIView
@property (nonatomic, strong) UIScrollView *scroll;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) NSMutableArray<NSValue *> *flags;
@property (nonatomic) CGFloat cursorY;
@property (nonatomic) CGFloat contentBottom;
- (void)fitHeight:(CGFloat)maxHeight;
@end

@implementation TGMenuPanel

- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        self.backgroundColor = [UIColor whiteColor];
        self.layer.cornerRadius = 16.f;
        self.layer.shadowColor = [UIColor blackColor].CGColor;
        self.layer.shadowOpacity = 0.16f;
        self.layer.shadowRadius = 14.f;
        self.layer.shadowOffset = CGSizeMake(0.f, 4.f);
        _flags = [NSMutableArray array];
        [self buildUI];
    }
    return self;
}

- (void)buildUI {
    // 顶部拖动条
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kPanelWidth, 44)];
    header.backgroundColor = [UIColor clearColor];
    [self addSubview:header];

    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(16, 12, 160, 20)];
    title.text = @"GHOST ESP";
    title.font = [UIFont systemFontOfSize:13 weight:UIFontWeightHeavy];
    title.textColor = [UIColor blackColor];
    [header addSubview:title];

    UILabel *sub = [[UILabel alloc] initWithFrame:CGRectMake(16, 28, 180, 12)];
    sub.text = @"The Ghost · 透视菜单";
    sub.font = [UIFont systemFontOfSize:9.5f weight:UIFontWeightMedium];
    sub.textColor = [UIColor colorWithWhite:0.55f alpha:1.f];
    [header addSubview:sub];

    UIButton *close = [UIButton buttonWithType:UIButtonTypeSystem];
    close.frame = CGRectMake(kPanelWidth - 44, 8, 36, 32);
    [close setTitle:@"✕" forState:UIControlStateNormal];
    [close setTitleColor:[UIColor colorWithWhite:0.25f alpha:1.f] forState:UIControlStateNormal];
    close.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightSemibold];
    [close addTarget:self action:@selector(onClose) forControlEvents:UIControlEventTouchUpInside];
    [header addSubview:close];

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(onDrag:)];
    [header addGestureRecognizer:pan];

    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, 43.5f, kPanelWidth, 0.5f)];
    line.backgroundColor = [UIColor colorWithWhite:0.f alpha:0.08f];
    [self addSubview:line];

    _scroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 44, kPanelWidth, 100)];
    _scroll.showsVerticalScrollIndicator = NO;
    _scroll.alwaysBounceVertical = YES;
    [self addSubview:_scroll];

    _cursorY = 4.f;

    [self addSection:@"幽灵"];
    [self addRow:@"鬼透视" flag:&g_set.ghostOn];
    [self addRow:@"只显示敌方" flag:&g_set.onlyEnemy];
    [self addRow:@"方框" flag:&g_set.ghostBox];
    [self addRow:@"骨骼" flag:&g_set.ghostSkel];
    [self addRow:@"名字" flag:&g_set.ghostName];
    [self addRow:@"距离" flag:&g_set.ghostDist];
    [self addRow:@"射线" flag:&g_set.ghostRay];

    [self addSection:@"物品"];
    [self addRow:@"物品透视" flag:&g_set.itemOn];
    [self addRow:@"名字" flag:&g_set.itemName];
    [self addRow:@"数量" flag:&g_set.itemCount];
    [self addRow:@"距离" flag:&g_set.itemDist];

    _statusLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, _cursorY + 6, kPanelWidth - 32, 16)];
    _statusLabel.font = [UIFont systemFontOfSize:10 weight:UIFontWeightMedium];
    _statusLabel.textColor = [UIColor colorWithWhite:0.45f alpha:1.f];
    _statusLabel.text = @"等待游戏加载…";
    [_scroll addSubview:_statusLabel];
    _cursorY += 30;

    _contentBottom = _cursorY;
    _scroll.contentSize = CGSizeMake(kPanelWidth, _contentBottom);
}

- (void)addSection:(NSString *)text {
    UILabel *l = [[UILabel alloc] initWithFrame:CGRectMake(16, _cursorY + 6, kPanelWidth - 32, 14)];
    l.text = text;
    l.font = [UIFont systemFontOfSize:9.5f weight:UIFontWeightSemibold];
    l.textColor = [UIColor colorWithWhite:0.5f alpha:1.f];
    [_scroll addSubview:l];
    _cursorY += 24.f;
}

- (void)addRow:(NSString *)text flag:(bool *)flag {
    UIView *row = [[UIView alloc] initWithFrame:CGRectMake(0, _cursorY, kPanelWidth, kRowHeight)];
    row.backgroundColor = [UIColor clearColor];

    UILabel *l = [[UILabel alloc] initWithFrame:CGRectMake(16, 0, 170, kRowHeight)];
    l.text = text;
    l.font = [UIFont systemFontOfSize:13.f weight:UIFontWeightRegular];
    l.textColor = [UIColor blackColor];
    [row addSubview:l];

    UISwitch *s = [[UISwitch alloc] initWithFrame:CGRectMake(kPanelWidth - 60, 4, 51, 31)];
    s.transform = CGAffineTransformMakeScale(0.7f, 0.7f);
    s.center = CGPointMake(kPanelWidth - 36.f, kRowHeight / 2.f);
    s.onTintColor = [UIColor blackColor];
    s.on = flag ? *flag : NO;
    s.tag = (NSInteger)_flags.count;
    [_flags addObject:[NSValue valueWithPointer:flag]];
    [s addTarget:self action:@selector(onSwitch:) forControlEvents:UIControlEventValueChanged];
    [row addSubview:s];

    UIView *sep = [[UIView alloc] initWithFrame:CGRectMake(16, kRowHeight - 0.5f, kPanelWidth - 32, 0.5f)];
    sep.backgroundColor = [UIColor colorWithWhite:0.f alpha:0.06f];
    [row addSubview:sep];

    [_scroll addSubview:row];
    _cursorY += kRowHeight;
}

- (void)onSwitch:(UISwitch *)s {
    if (s.tag < 0 || s.tag >= (NSInteger)_flags.count) return;
    bool *flag = (bool *)[_flags[(NSUInteger)s.tag] pointerValue];
    if (flag) *flag = s.isOn;
    tg_settings_save();
}

- (void)onClose { self.hidden = YES; }

- (void)onDrag:(UIPanGestureRecognizer *)g {
    UIView *sv = self.superview;
    if (!sv) return;
    CGPoint t = [g translationInView:sv];
    CGPoint c = self.center;
    c.x += t.x;
    c.y += t.y;
    CGFloat halfW = CGRectGetWidth(self.bounds) / 2.f;
    CGFloat halfH = CGRectGetHeight(self.bounds) / 2.f;
    c.x = MAX(halfW + 4.f, MIN(c.x, CGRectGetWidth(sv.bounds) - halfW - 4.f));
    c.y = MAX(halfH + 4.f, MIN(c.y, CGRectGetHeight(sv.bounds) - halfH - 4.f));
    self.center = c;
    [g setTranslation:CGPointZero inView:sv];
}

/// 按内容高度调整自身高度（不超过 maxHeight）
- (void)fitHeight:(CGFloat)maxHeight {
    CGFloat h = MIN(_contentBottom + 44.f + 8.f, maxHeight);
    CGRect f = self.frame;
    f.size.height = h;
    self.frame = f;
    _scroll.frame = CGRectMake(0, 44, kPanelWidth, h - 44.f);
    _scroll.contentSize = CGSizeMake(kPanelWidth, _contentBottom);
}

@end

// ---------------------------------------------------------------------------
// 总控
// ---------------------------------------------------------------------------
@interface TGOverlay () <UIGestureRecognizerDelegate>
@end

@implementation TGOverlay {
    UIWindow *_window;
    TGPassthroughView *_root;
    TGESPView *_espView;
    UIButton *_button;
    TGMenuPanel *_panel;
    NSTimer *_statusTimer;
    BOOL _panelVisible;
}

+ (instancetype)shared {
    static TGOverlay *obj = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ obj = [[TGOverlay alloc] init]; });
    return obj;
}

- (void)install {
    dispatch_async(dispatch_get_main_queue(), ^{
        tg_settings_load();
        [self setupWindow];
        tg_esp_start();
        [self startStatusTimer];
    });
}

- (void)setupWindow {
    if (_window) return;

    CGRect bounds = [UIScreen mainScreen].bounds;
    _window = [[TGPassthroughWindow alloc] initWithFrame:bounds];
    // 保持在游戏普通窗口之上，但不覆盖系统 Alert / 键盘等窗口。
    _window.windowLevel = UIWindowLevelNormal + 1;
    _window.backgroundColor = [UIColor clearColor];
    _window.hidden = NO;

    UIViewController *vc = [[UIViewController alloc] init];
    TGPassthroughView *root = [[TGPassthroughView alloc] initWithFrame:bounds];
    root.backgroundColor = [UIColor clearColor];
    root.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    vc.view = root;
    _window.rootViewController = vc;
    _root = root;

    // 透视画布
    _espView = [[TGESPView alloc] initWithFrame:bounds];
    _espView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [root addSubview:_espView];

    // 悬浮按钮
    _button = [UIButton buttonWithType:UIButtonTypeCustom];
    _button.frame = CGRectMake(CGRectGetWidth(bounds) - 66.f, 74.f, 46.f, 46.f);
    _button.backgroundColor = [UIColor whiteColor];
    _button.layer.cornerRadius = 23.f;
    _button.layer.borderWidth = 1.5f;
    _button.layer.borderColor = [UIColor blackColor].CGColor;
    _button.layer.shadowColor = [UIColor blackColor].CGColor;
    _button.layer.shadowOpacity = 0.18f;
    _button.layer.shadowRadius = 8.f;
    _button.layer.shadowOffset = CGSizeMake(0.f, 2.f);
    _button.titleLabel.font = [UIFont systemFontOfSize:11.f weight:UIFontWeightHeavy];
    [_button setTitle:@"ESP" forState:UIControlStateNormal];
    [_button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_button addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(dragButton:)];
    pan.delegate = self;
    [_button addGestureRecognizer:pan];
    [root addSubview:_button];

    // 菜单
    CGRect pf = CGRectMake(12.f, 130.f, 254.f, 300.f);
    _panel = [[TGMenuPanel alloc] initWithFrame:pf];
    CGFloat maxH = CGRectGetHeight(bounds) - 100.f;
    [_panel fitHeight:maxH];
    _panel.hidden = YES;
    [root addSubview:_panel];
    _panelVisible = NO;

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(onRotate)
                                                 name:UIDeviceOrientationDidChangeNotification
                                               object:nil];
}

- (void)onRotate {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!self->_root) return;
        CGFloat w = CGRectGetWidth(self->_root.bounds);
        CGFloat h = CGRectGetHeight(self->_root.bounds);
        CGRect bf = self->_button.frame;
        bf.origin.x = MIN(bf.origin.x, w - bf.size.width - 6.f);
        bf.origin.y = MIN(bf.origin.y, h - bf.size.height - 6.f);
        self->_button.frame = bf;
        [self->_panel fitHeight:h - 100.f];
        [self layoutPanel];
    });
}

- (void)startStatusTimer {
    if (_statusTimer) return;
    __weak __typeof__(self) weakSelf = self;
    _statusTimer = [NSTimer scheduledTimerWithTimeInterval:0.5 repeats:YES block:^(NSTimer *t) {
        __typeof__(self) s = weakSelf;
        if (!s) return;
        [s refreshStatus];
    }];
}

- (void)refreshStatus {
    if (!_panel) return;
    TGFrame f;
    tg_esp_copy_frame(&f);
    if (tg_game_bound()) {
        _panel.statusLabel.text = [NSString stringWithFormat:@"已连接 · 鬼 %d · 物品 %d",
                                   f.ghostCount, f.itemCount];
    } else {
        _panel.statusLabel.text = @"等待游戏加载…";
    }
}

- (void)togglePanel {
    _panelVisible = !_panelVisible;
    _panel.hidden = !_panelVisible;
    if (_panelVisible) [self layoutPanel];
}

- (void)layoutPanel {
    if (!_panel || !_root) return;
    CGFloat w = CGRectGetWidth(_root.bounds);
    CGFloat h = CGRectGetHeight(_root.bounds);
    CGRect bf = _button.frame;
    CGFloat x = bf.origin.x - CGRectGetWidth(_panel.frame) - 8.f;
    if (x < 8.f) x = 8.f;
    CGFloat y = MIN(bf.origin.y, h - CGRectGetHeight(_panel.frame) - 8.f);
    if (y < 8.f) y = 8.f;
    CGRect f = _panel.frame;
    f.origin = CGPointMake(x, y);
    _panel.frame = f;
    (void)w;
}

- (void)dragButton:(UIPanGestureRecognizer *)g {
    UIView *sv = _root;
    if (!sv) return;
    CGPoint t = [g translationInView:sv];
    CGPoint c = _button.center;
    c.x += t.x;
    c.y += t.y;
    CGFloat half = CGRectGetWidth(_button.bounds) / 2.f;
    c.x = MAX(half + 4.f, MIN(c.x, CGRectGetWidth(sv.bounds) - half - 4.f));
    c.y = MAX(half + 4.f, MIN(c.y, CGRectGetHeight(sv.bounds) - half - 4.f));
    _button.center = c;
    [g setTranslation:CGPointZero inView:sv];
    if (_panelVisible) [self layoutPanel];
}

#pragma mark - UIGestureRecognizerDelegate

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)g shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)other {
    return YES;
}

@end
