//
//  Entry.mm
//  TheGhostESP
//
//  注入后的入口：等游戏起来 -> 绑定 IL2CPP -> 挂悬浮层。
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "Game.h"
#import "ESP.h"
#import "Overlay.h"

static NSTimer *g_retryTimer = NULL;
static int g_retryCount = 0;

static void tg_boot(void) {
    if (tg_game_bound()) {
        [g_retryTimer invalidate];
        g_retryTimer = NULL;
        NSLog(@"[TheGhostESP] 游戏已就绪，挂载悬浮层");
        [[TGOverlay shared] install];
        return;
    }

    if (tg_game_bind()) {
        [g_retryTimer invalidate];
        g_retryTimer = NULL;
        NSLog(@"[TheGhostESP] IL2CPP 绑定成功，挂载悬浮层");
        [[TGOverlay shared] install];
        return;
    }

    // 最多等 120 秒（进对局 / 过加载场景都可能慢）
    if (++g_retryCount > 120) {
        [g_retryTimer invalidate];
        g_retryTimer = NULL;
        NSLog(@"[TheGhostESP] 等待超时：没有找到游戏类，可能版本不匹配");
    }
}

__attribute__((constructor))
static void tg_entry(void) {
    NSLog(@"[TheGhostESP] dylib 已注入，等待游戏初始化");

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        if (!g_retryTimer) {
            g_retryTimer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                            repeats:YES
                                                              block:^(NSTimer *t) {
                tg_boot();
            }];
        }
        tg_boot();
    });
}
