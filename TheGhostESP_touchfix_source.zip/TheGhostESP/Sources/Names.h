//
//  Names.h
//  TheGhostESP
//
//  中文名表（全部来自 dump 里的 PrefabId / Model 枚举）
//

#ifndef NAMES_H
#define NAMES_H

#include <stdint.h>
#include <stddef.h>

typedef struct { uint16_t id; const char *cn; } TGNameEntry;

// 钥匙类 1 ~ 21 / 工具与任务物品 100 ~ 146
static const TGNameEntry kPrefabNames[] = {
    {1,   "红钥匙"},
    {2,   "绿钥匙"},
    {3,   "蓝钥匙"},
    {4,   "学校钥匙"},
    {5,   "生锈钥匙"},
    {6,   "皇家钥匙"},
    {7,   "木钥匙"},
    {8,   "工具箱钥匙"},
    {9,   "四号模块钥匙"},
    {10,  "二号模块钥匙"},
    {11,  "笼房钥匙"},
    {12,  "压力房钥匙"},
    {13,  "储藏室钥匙"},
    {14,  "维修间钥匙"},
    {15,  "淹水地下室钥匙"},
    {16,  "排水间钥匙"},
    {17,  "水库房钥匙"},
    {18,  "下层枢纽钥匙"},
    {19,  "深层枢纽储藏室钥匙"},
    {20,  "深层枢纽大门钥匙"},
    {21,  "深层枢纽钥匙"},

    {100, "十字架"},
    {101, "开锁器"},
    {102, "车轮"},
    {103, "车电瓶"},
    {104, "车油桶"},
    {105, "车钥匙"},
    {106, "代币"},
    {107, "保险丝"},
    {108, "铃铛"},
    {109, "画"},
    {110, "园艺剪"},
    {111, "棘轮扳手"},
    {112, "磁带"},
    {113, "按钮"},
    {114, "庄园画"},
    {115, "齿轮锁"},
    {116, "医疗包"},
    {117, "红保险丝"},
    {118, "绿保险丝"},
    {119, "蓝保险丝"},
    {120, "黄保险丝"},
    {121, "粉保险丝"},
    {122, "篮球"},
    {123, "胶带"},
    {124, "数字六"},
    {125, "汽油桶"},
    {126, "小麦"},
    {127, "拉杆"},
    {128, "霰弹枪"},
    {129, "霰弹"},
    {130, "鬼魂探测器"},
    {131, "刮痕"},
    {132, "带线钩"},
    {133, "阀门"},
    {134, "药片"},
    {135, "草药"},
    {136, "温度计"},
    {137, "蜡烛"},
    {138, "通灵盒"},
    {139, "EMF 探测器"},
    {140, "仪式书"},
    {141, "仪式箱"},
    {142, "圣书"},
    {143, "下水道阀门"},
    {144, "缺失开关"},
    {145, "指南针"},
    {146, "撬棍"},
};

// 鬼的模型（Model 枚举 0~23）
static const char *kModelNames[] = {
    "韦德", "马克", "汉娜", "鲍勃", "艾米莉", "小戈德薇拉", "石像", "爬行者",
    "庄园鬼", "老巫鬼", "潜行者", "警笛头", "蕨怪", "屠夫", "穿墙巫鬼", "莫莫",
    "飞头", "霉仆", "瘦长鬼影", "南瓜怪", "圣诞机械玩偶", "屠宰鬼", "诅咒娃娃", "地下室手臂",
};

static inline const char *tg_prefab_name(uint16_t id) {
    const size_t n = sizeof(kPrefabNames) / sizeof(kPrefabNames[0]);
    for (size_t i = 0; i < n; i++) {
        if (kPrefabNames[i].id == id) return kPrefabNames[i].cn;
    }
    return NULL;
}

// 钥匙 1~21 / 物品 100~146 算“物品”；道具 1000+ 是场景装饰，不画
static inline bool tg_is_item_prefab(uint16_t id) {
    return (id >= 1 && id <= 21) || (id >= 100 && id <= 146);
}

static inline const char *tg_model_name(int model) {
    const int n = (int)(sizeof(kModelNames) / sizeof(kModelNames[0]));
    if (model >= 0 && model < n) return kModelNames[model];
    return "未知单位";
}

#endif /* NAMES_H */
