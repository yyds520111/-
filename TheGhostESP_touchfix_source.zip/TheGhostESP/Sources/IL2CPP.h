//
//  IL2CPP.h
//  TheGhostESP
//
//  IL2CPP 运行时 API 的动态解析层。
//  不写死任何地址：所有类 / 字段 / 方法都按名字在运行时查找，
//  游戏小版本更新只要类名、字段名没变就能继续用（dump 里的偏移只当兜底）。
//

#ifndef IL2CPP_H
#define IL2CPP_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#ifdef __OBJC__
@class NSString;
#endif

typedef struct Il2CppDomain   Il2CppDomain;
typedef struct Il2CppAssembly Il2CppAssembly;
typedef struct Il2CppImage    Il2CppImage;
typedef struct Il2CppClass    Il2CppClass;
typedef struct Il2CppObject   Il2CppObject;
typedef struct Il2CppString   Il2CppString;
typedef struct MethodInfo     MethodInfo;
typedef struct FieldInfo      FieldInfo;
typedef struct Il2CppException Il2CppException;

// Unity 内部结构（与 UnityEngine.Vector3 / Quaternion 内存布局一致）
typedef struct { float x, y, z; } Vec3;
typedef struct { float x, y, z, w; } Quat;

typedef struct {
    Il2CppDomain *(*domain_get)(void);
    const Il2CppAssembly **(*domain_get_assemblies)(const Il2CppDomain *domain, size_t *size);
    const Il2CppImage *(*assembly_get_image)(const Il2CppAssembly *assembly);
    const char *(*image_get_name)(const Il2CppImage *image);
    size_t (*image_get_class_count)(const Il2CppImage *image);
    Il2CppClass *(*image_get_class)(const Il2CppImage *image, size_t index);

    const char *(*class_get_name)(const Il2CppClass *klass);
    const char *(*class_get_namespace)(const Il2CppClass *klass);
    Il2CppClass *(*class_get_parent)(const Il2CppClass *klass);
    Il2CppClass *(*class_from_name)(const Il2CppImage *image, const char *ns, const char *name);

    FieldInfo *(*class_get_field_from_name)(Il2CppClass *klass, const char *name);
    int32_t (*field_get_offset)(FieldInfo *field);

    const MethodInfo *(*class_get_method_from_name)(Il2CppClass *klass, const char *name, int argsCount);
    void *(*method_get_pointer)(const MethodInfo *method); // 可能为 NULL（旧版本没有）

    Il2CppObject *(*runtime_invoke)(const MethodInfo *method, void *obj, void **params, Il2CppException **exc);
    void *(*object_unbox)(Il2CppObject *obj);
    Il2CppClass *(*object_get_class)(Il2CppObject *obj);
    void (*thread_attach)(Il2CppDomain *domain);
} IL2CPPApi;

extern IL2CPPApi g_il2cpp;
extern int      g_il2cppReady;

/// 解析全部 il2cpp_* 导出符号。成功返回 1。
int  il2cpp_api_load(void);

/// 按类名（可指定命名空间，传 NULL 表示任意命名空间）在全部程序集中查找类。
/// 结果会缓存。
Il2CppClass *il2cpp_find_class(const char *name, const char *ns);

/// 按字段名查找（自动沿继承链向上找）。
FieldInfo *il2cpp_find_field(Il2CppClass *klass, const char *name);

/// 取字段偏移；查不到时返回 fallback（来自 dump 的偏移）。
int il2cpp_field_offset(Il2CppClass *klass, const char *name, int fallback);

/// 取方法（自动沿继承链向上找）。
const MethodInfo *il2cpp_find_method(Il2CppClass *klass, const char *name, int argsCount);

/// 取方法的直接调用地址（不走 runtime_invoke，速度快十倍）。
void *il2cpp_method_ptr(const MethodInfo *method);

// ---------------------------------------------------------------------------
// 内存读取小工具（IL2CPP 对象布局是固定的）
// ---------------------------------------------------------------------------

static inline void *tg_read_ptr(void *base, int off) {
    if (!base || off <= 0) return NULL;
    return *(void **)((char *)base + off);
}

static inline int32_t tg_read_i32(void *base, int off) {
    if (!base || off <= 0) return 0;
    return *(int32_t *)((char *)base + off);
}

static inline uint16_t tg_read_u16(void *base, int off) {
    if (!base || off <= 0) return 0;
    return *(uint16_t *)((char *)base + off);
}

static inline bool tg_read_u8(void *base, int off) {
    if (!base || off <= 0) return 0;
    return *(uint8_t *)((char *)base + off) != 0;
}

static inline float tg_read_f32(void *base, int off) {
    if (!base || off <= 0) return 0.f;
    return *(float *)((char *)base + off);
}

static inline Vec3 tg_read_vec3(void *base, int off) {
    Vec3 v = {0, 0, 0};
    if (!base || off <= 0) return v;
    v = *(Vec3 *)((char *)base + off);
    return v;
}

// 数组：0x00 klass / 0x08 monitor / 0x10 bounds / 0x18 length / 0x20 数据
static inline size_t tg_array_len(void *arr) {
    if (!arr) return 0;
    return *(size_t *)((char *)arr + 0x18);
}

static inline void *tg_array_at(void *arr, size_t i) {
    if (!arr) return NULL;
    return *(void **)((char *)arr + 0x20 + i * 8);
}

// 字符串：0x10 长度(int32) / 0x14 UTF-16 数据
static inline int32_t tg_string_length(void *str) {
    if (!str) return 0;
    return *(int32_t *)((char *)str + 0x10);
}

static inline const uint16_t *tg_string_chars(void *str) {
    if (!str) return NULL;
    return (const uint16_t *)((char *)str + 0x14);
}

/// 取对象的运行时类名（用于校验指针类型，防止错字段导致崩溃）
const char *tg_object_class_name(void *obj);

/// 把 Il2CppString 转成 NSString；不合法返回 nil。
/// 会做边界与可读性校验，避免个别字段偏移不对时崩溃。
NSString *tg_nsstring(void *il2cppString);

/// 判断一个指针看上去是不是合法的 Il2CppString。
bool tg_looks_like_string(void *ptr);

#endif /* IL2CPP_H */
