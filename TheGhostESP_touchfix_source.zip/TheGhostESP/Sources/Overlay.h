//
//  Overlay.h
//  TheGhostESP
//

#import <UIKit/UIKit.h>

@interface TGOverlay : NSObject
+ (instancetype)shared;
- (void)install;
@end
