# The Ghost ESP（iOS dylib）

给《The Ghost / 鬼魂》写的透视 dylib：鬼 + 物品的 ESP，白色简洁悬浮菜单。
非越狱机器走「砸壳 IPA + 全能签注入 dylib」这条路，所以整个工程是按 **纯 dylib** 写的
（不依赖 Cydia / 越狱环境）。

---

## 一、这套代码干了什么

**扫描来源**（全部来自你给的 dump.cs，字段名 + 偏移都核对过）

| 用途 | 类 | 成员 | 偏移 |
|---|---|---|---|
| 玩家列表 | `GameClient.GameManager` | `clients`（NetworkEntityClient[]） | 0x20 |
| 全部实体 | `GameClient.GameManager` | `cachedEntities`（NetworkEntity[]） | 0x120 |
| 可交互实体（兜底） | `GameClient.GameManager` | `cachedInteractableEntities` | 0x128 |
| 本地玩家 | `GameClient.GameManager` | `_localPlayer` | 0x38 |
| 实体 ID / 预制体 / 模型根节点 | `NetworkEntity` | `Id` / `PrefabId` / `_gfx` | 0x20 / 0x2C / 0x78 |
| 鬼的模型、骨骼、名字、阵营 | `NetworkEntityClient` | `characterModelType` / `_animator` / `usernameText` / `enemy` | 0x1A4 / 0x3C0 / 0x468 / 0x528 |

**关键点：偏移不是写死的。** 启动时会用 `il2cpp_class_get_field_from_name` + `il2cpp_field_get_offset`
按**字段名**重新取一遍真实偏移，上面的 dump 值只当兜底。所以游戏小版本改动（字段顺序变了但名字没变）
照样能用，不用重新 dump 地址。

**功能**

- 鬼 ESP：方框、骨骼、名字（中文）、距离、射线，只看敌方 / 看全部可切换
- 物品 ESP：中文名、数量（同类物品数量）、距离
- 物品覆盖：钥匙 1~21、工具/任务物品 100~146（中文名表在 `Sources/Names.h`，一个不漏）
- 鬼的名字用 `Model` 枚举翻成中文（庄园鬼 / 老巫鬼 / 警笛头 / 屠夫 / 瘦长鬼影 …），
  能读到玩家名就拼成「庄园鬼 · 玩家名」
- 白色悬浮菜单：右上角 ESP 圆钮，点开是开关面板，可拖动；设置自动保存

**性能**：扫描跑在独立线程（30Hz），主线程只负责画；画布不接管触摸，不影响你操作游戏。

---

## 二、编译（这台机器没有苹果编译链，三选一）

工程是标准的 theos / Xcode 工程，**代码是完整的，不是空壳**，但 dylib 必须在能出 iOS 二进制的环境里编：

### 方式 1：GitHub Actions（不用 Mac，最省事）

1. 新建一个 GitHub 仓库，把本目录整个推上去
2. 进 Actions → 选 `build-dylib` → Run workflow
3. 跑完在 Artifacts 里下载 `TheGhostESP-dylib`，解压就是 `TheGhostESP.dylib`

流水线已经配好（`.github/workflows/build.yml`，macos-14 runner，编完自动 `lipo -info` 校验）。

### 方式 2：自己的 Mac

```bash
cd TheGhostESP
chmod +x build.sh
./build.sh              # 产出 TheGhostESP.dylib
```

需要 Xcode 或 Command Line Tools（`xcode-select --install`）。

### 方式 3：theos（越狱环境打包用）

```bash
export THEOS=~/theos
make package
```

---

## 三、注入（非越狱 / iOS 18.6）

1. 准备**已砸壳**的 IPA（App Store 原版是加密的，直接注入必闪退）
2. 全能签 / ESign：导入 IPA → 「注入 dylib」→ 选 `TheGhostESP.dylib`
3. 用自己的证书签名 → 安装
4. 进游戏，等 2~5 秒（进对局后），右上角出现白色 **ESP** 圆钮 → 点开就是开关面板

日志前缀 `[TheGhostESP]`，用 Console.app 或 Xcode 设备日志能看到绑定结果：

```
[TheGhostESP] 绑定成功 clients=0x20 entities=0x120 gfx=0x78 animator=0x3C0 enemy=0x528
```

---

## 四、工程结构

```
TheGhostESP/
├── Makefile                        theos 构建
├── build.sh                        macOS 一键编译
├── .github/workflows/build.yml     CI 一键编译
└── Sources/
    ├── IL2CPP.h / .mm              il2cpp_* 符号动态解析、类/字段/方法查找、字符串转换
    ├── Game.h / .mm                游戏绑定层（GameManager / NetworkEntity / Camera / Animator）
    ├── ESP.h / .mm                 扫描 + 世界坐标转屏幕 + 骨骼数据（30Hz 独立线程）
    ├── Names.h                     中文名表（PrefabId / Model）
    └── Overlay.mm                  透明画布 + 白色菜单 + 悬浮窗
```

---

## 五、版本更新了怎么办

1. 重新用 Il2CppDumper 出 `dump.cs`
2. 只看这几个类有没有改名/改字段：
   - `GameClient.GameManager`：`clients` / `cachedEntities` / `_localPlayer`
   - `NetworkEntity`：`Id` / `PrefabId` / `_gfx`
   - `NetworkEntityClient`：`characterModelType` / `_animator` / `usernameText` / `enemy`
3. 名字没变 → 重新编译就行，代码自己会取到新偏移
4. 名字变了 → 改 `Sources/Game.mm` 里那几行字符串，顺便把注释里的新偏移也改一下

---

## 六、已知边界（说清楚，不吹）

- **只读透视**：没有任何写内存 / 改数值的操作，所以不会碰 `GameServer.EntityVelocityLimitCheck`
  这类位移校验，也不影响服务端权威逻辑（血量、伤害、分数都在服务端算）
- **鬼 = 敌方玩家**：这个游戏里「鬼」是一个玩家扮演的角色，代码按 `NetworkEntityClient.enemy`
  筛选。如果后续模式里出现纯 AI 怪物实体（`BalmsMonster` / `AIMovement*` 那一套），
  需要在 `ESP.mm` 的物品循环旁边再加一段实体过滤（框架已经在那里，加个 prefab 判断就行）
- **物品数量**是「当前视野内同类物品的个数」，不是背包堆叠数（世界实体本身不带堆叠字段）
- 需要砸壳 IPA；加密包注入必崩
- 骨骼依赖 Unity Humanoid Rig（`Animator.GetBoneTransform`），拿不到骨骼时自动退回「头顶 + 脚下」的估算框
