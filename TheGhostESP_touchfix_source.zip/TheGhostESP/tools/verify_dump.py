#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
dump.cs 版本校验：游戏更新后先跑这个，确认代码里用到的类/字段/偏移还在不在。

用法:
    python3 tools/verify_dump.py dump.cs
"""
import re
import sys

# (类名, 命名空间, [字段名...])
EXPECT = [
    ("GameManager", "GameClient", ["clients", "cachedEntities", "cachedInteractableEntities", "_localPlayer"]),
    ("NetworkEntity", None, ["Id", "PrefabId", "_gfx"]),
    ("NetworkEntityClient", None, ["characterModelType", "_animator", "usernameText", "enemy",
                                   "<PlayerDead>k__BackingField"]),
]

CLASS_RE = re.compile(r"^// Namespace: (.*)$")


def scan(path):
    """返回 {类名: (命名空间, {字段: 偏移})}"""
    out = {}
    ns = ""
    cur = None
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.rstrip("\n")
            m = CLASS_RE.match(line)
            if m:
                ns = m.group(1).strip()
                continue
            m = re.match(r"^public (?:sealed |abstract )?class (\w+)", line)
            if m:
                cur = (m.group(1), ns, {})
                out.setdefault(m.group(1), []).append(cur)
                continue
            m = re.match(r"^\t(?:public |private |protected |internal )?(?:static )?(?:readonly )?[\w\.<>,\[\]\s]+?\s([\w<>`]+); // (0x[0-9A-Fa-f]+)$", line)
            if m and cur:
                cur[2][m.group(1)] = int(m.group(2), 16)
    return out


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    classes = scan(sys.argv[1])
    bad = 0
    for name, ns, fields in EXPECT:
        cands = classes.get(name, [])
        if ns:
            cands = [c for c in cands if c[1] == ns]
        # NetworkEntity 有多个同名类，挑带 PrefabId 的那个
        cands = [c for c in cands if "PrefabId" in c[2]] if name == "NetworkEntity" else cands
        if not cands:
            print(f"[缺失] 类 {ns or '*'}::{name}")
            bad += 1
            continue
        cls = cands[0]
        print(f"[OK] {cls[1] or '<global>'}::{name}")
        for fname in fields:
            off = cls[2].get(fname)
            if off is None:
                print(f"       [缺失] 字段 {fname}")
                bad += 1
            else:
                print(f"       {fname:<32} 0x{off:X}")
    print()
    print("结论:", "全部对得上，可以直接编译" if bad == 0 else f"有 {bad} 项对不上，需要改 Sources/Game.mm 里的字段名")
    return 0 if bad == 0 else 2


if __name__ == "__main__":
    sys.exit(main())
