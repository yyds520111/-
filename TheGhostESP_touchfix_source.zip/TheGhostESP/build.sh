#!/bin/bash
# 在 macOS（装了 Xcode / Command Line Tools）上直接编出 iOS dylib。
# 用法： ./build.sh            产出 TheGhostESP.dylib
#        ./build.sh out.dylib  指定输出名

set -euo pipefail

OUT="${1:-TheGhostESP.dylib}"
cd "$(dirname "$0")"

SDK="$(xcrun --sdk iphoneos --show-sdk-path)"
echo "==> SDK: $SDK"

SRC=$(ls Sources/*.mm)

xcrun --sdk iphoneos clang++ \
    -dynamiclib \
    -fobjc-arc \
    -O2 \
    -fvisibility=hidden \
    -isysroot "$SDK" \
    -miphoneos-version-min=15.0 \
    -arch arm64 \
    -arch arm64e \
    -I Sources \
    -framework UIKit \
    -framework Foundation \
    -framework QuartzCore \
    -framework CoreGraphics \
    -install_name @executable_path/Frameworks/TheGhostESP.dylib \
    -o "$OUT" \
    $SRC

echo "==> 产物: $OUT"
file "$OUT"
ls -lh "$OUT"
